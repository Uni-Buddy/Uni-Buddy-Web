// 일지 작성 페이지 - 수정 중

import "./Test.css";

import React, { Component } from "react";
const curr = new Date();

document.writeln(curr);
class InputForm extends Component {
  state = {
    title: "",
    company: "",
    content: "",
  };

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  handleSubmit = (e) => {
    e.preventDefault(); //새로고침 방지
    this.props.onCreate(this.state);
    this.setState({
      //input값 빈값으로 초기화
      title: "",
      company: "",
      content: "",
    });
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <input
          name="title"
          onChange={this.handleChange}
          value={this.state.title}
          placeholder="제목"
        />
        <input
          name="company"
          onChange={this.handleChange}
          value={this.state.company}
          placeholder="기관"
        />
        <input
          name="content"
          onChange={this.handleChange}
          value={this.state.content}
          placeholder="내용"
        />
        <button type="submit">완료</button>
      </form>
    );
  }
}

export default InputForm;
