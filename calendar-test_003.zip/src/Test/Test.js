// 일지 작성 페이지 - 수정 중

import "./Test.css";
import Head from "../pages/Diarywritepage/img/Start.png";
import Icon from "../pages/Diarywritepage/img/Write.png";
import Nav from "../pages/Diarywritepage/Nav";
import Top from "../pages/component/Top.js";

import InputForm from "./InputForm";

import React, { Component } from "react";
// 카테고리 선택
const checkOnlyOne = (checkThis) => {
  const checkboxes = document.getElementsByName("test");
  for (let i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i] !== checkThis) {
      checkboxes[i].checked = false;
    }
  }
};

class Diarywrite extends Component {
  id = 0;

  state = {
    users: [],
  };

  // UTC 한국 시간 설정
  handleCreate = (data) => {
    this.setState({
      users: this.state.users.concat({
        ...data,
        id: this.id++,
      }),
    });
  };

  handleDateChange = (event) => {
    const date = new Date(event.target.value);
    const koreanDate = date.toLocaleDateString("ko-KR");
    this.setState({ date: koreanDate });
  };

  handleSubmit = (event) => {
    event.preventDefault();
    const data = this.state.date;
    // 여기에 데이터 저장 로직을 추가하세요.
    console.log(data);
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        {/* 배경 및 아이콘 */}
        <header>
          <img src={Head} alt="Head" className="W_Head" />
          <div className="W_Icon">
            <div className="W_Bigcircle">
              <img src={Icon} alt="Icon" className="W_Writeimg" />
            </div>
            <div className="W_Smallcircle"></div>
            <p className="W_Iconwrite">기록</p>
          </div>
        </header>
        {/* 로고 및 메뉴바 */}
        <Nav />
        {/* 일지 작성 */}
        <section className="W_Section">
          <InputForm onCreate={this.handleCreate} />
          {JSON.stringify(this.state.users)}
        </section>

        <section className="W_Section">
          <article className="W_Article">
            {/* 일지 : 제목 */}
            <input className="W_Title" type="text" placeholder="제목" />
            {/* 구분선 = 직선 = hr태그 */}
            <hr className="W_Hr" />
            {/* 일지 : 카테고리 선택 */}
            <div className="W_Choice">
              <span className="W_Cartegory">카테고리 &nbsp;:</span>
              &nbsp;&nbsp;
              <span>
                <input
                  type="checkbox"
                  name="test"
                  value="1"
                  onChange={(e) => checkOnlyOne(e.target)}
                />
                {" 교내활동 "}
                &nbsp;&nbsp;
                <input
                  type="checkbox"
                  name="test"
                  value="2"
                  onChange={(e) => checkOnlyOne(e.target)}
                />
                {" 교외활동 "}
                &nbsp;&nbsp;
                <input
                  type="checkbox"
                  name="test"
                  value="3"
                  onChange={(e) => checkOnlyOne(e.target)}
                />
                {" 자격증 "}
                &nbsp;&nbsp;
                <input
                  type="checkbox"
                  name="test"
                  value="4"
                  onChange={(e) => checkOnlyOne(e.target)}
                />
                {" 어학 "}
              </span>
            </div>
            {/* 일지 : 기관 */}
            <span className="W_Place1">기관&nbsp;&nbsp;:</span>
            <input className="W_Place2" type="text" />
            {/* 일지 : 날짜 */}
            <span className="W_Date1">날짜&nbsp;&nbsp;:</span>
            <input
              className="W_Date2"
              type="date"
              placeholder="날짜"
              onChange={this.handleDateChange}
            />
            {/* 일지 : 내용 */}
            <textarea className="W_Text"></textarea>
            {/* 완료 및 취소 버튼 */}
            <aside className="W_Aside">
              {/* 완료 버튼 */}
              <button type="submit" className="W_Button1">
                완료
              </button>
              {/* 취소 버튼 */}
              <button className="W_Button1">취소</button>
            </aside>
          </article>
        </section>
        {/* 화면 최상단으로 이동하는 버튼 */}
        <footer className="W_Footer">
          <Top />
        </footer>
      </form>
    );
  }
}

export default Diarywrite;
