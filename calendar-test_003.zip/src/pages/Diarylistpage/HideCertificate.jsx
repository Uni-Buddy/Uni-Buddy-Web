// 자격증 리스트

import React from "react";
import './Diarylist.css';

const HideOut = () => {
    
    return (
        <>
        <article className="List_Article4">
          <div className="List_Listbox">
            <div className="List_Title">자격증</div>
            <div className="List_Content">내용</div>
          </div>
          <hr className="List_Hr" />
          <div className="List_Listbox">
            <div className="List_Title">자격증</div>
            <div className="List_Content">내용</div>
          </div>
          <hr className="List_Hr" />
        </article>
        </>
    );
};

export default HideOut;