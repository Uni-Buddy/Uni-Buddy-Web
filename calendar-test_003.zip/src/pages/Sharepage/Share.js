// 공유 페이지

import App from "./Share.jsx";

const Share = () => {
  return <App />;
};
export default Share;
