//import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./pages/Loginpage/Login";
import Register from "./pages/Registerpage/Register";
import Start from "./pages/Startpage/Start";
import Share from "./pages/Sharepage/Share";
import Diarylist from "./pages/Diarylistpage/Diarylist";
import Diarywrite from "./pages/Diarywritepage/Diarywrite";
import Mypage from "./pages/Mypage/Mypage";
import Editpi from "./pages/Mypage/Editpi";
import Changepswd from "./pages/Mypage/Changepswd";
import Time from "./pages/Timepage/Time";
import Test from "./Test/Test";
import Calendar from "./pages/Calendarpage/Calendar";

import React, { Component } from "react";
import Main from "./pages/Diarylistpage/main";
import Write from "./pages/Diarylistpage/write";
import Detail from "./pages/Diarylistpage/detail";

class App extends Component {
  render() {
    return (
      <Router>
        <Routes>
          <Route path="/" element={<Main />} />
          <Route path="/write" element={<Write />} />
          <Route path="/detail" element={<Detail />} />

          <Route path="/start" element={<Start />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/share" element={<Share />} />
          <Route path="/diarylist" element={<Diarylist />} />
          <Route path="/diarywrite" element={<Diarywrite />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path="/mypage" element={<Mypage />} />
          <Route path="/time" element={<Time />} />
          <Route path="/editPI" element={<Editpi />} />
          <Route path="/changepswd" element={<Changepswd />} />
          <Route path="/test" element={<Test />} />
        </Routes>
      </Router>
    );
  }
}

export default App;

/*
const App = () => {
  return (
    <Router>
      <Routes>
        <Route exact path="/" component={Main} />
        <Route path="/write" component={Write} />
        <Route path="/detail" component={Detail} />

        <Route path="/" element={<Start />} />
        <Route path="/start" element={<Start />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/share" element={<Share />} />
        <Route path="/diarylist" element={<Diarylist />} />
        <Route path="/diarywrite" element={<Diarywrite />} />
        <Route path="/calendar" element={<Calendar />} />
        <Route path="/mypage" element={<Mypage />} />
        <Route path="/time" element={<Time />} />
        <Route path="/editPI" element={<Editpi />} />
        <Route path="/changepswd" element={<Changepswd />} />
        <Route path="/test" element={<Test />} />
        <Route path="/@username">
          <Route index element={<Start />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;
*/
