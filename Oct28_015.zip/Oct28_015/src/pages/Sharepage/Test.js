import Test from "./test.jsx";

const Share = () => {
  return <Test />;
};
export default Share;
