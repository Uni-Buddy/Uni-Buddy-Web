export { default } from "./ViewComponent";
