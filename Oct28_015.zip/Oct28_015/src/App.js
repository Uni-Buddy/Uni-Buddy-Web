import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Provider } from "react-redux"; // Redux Provider 추가
import { createStore, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import rootReducer from "./pages/store/rootReducer";
import Login from "./pages/Loginpage/Login";
import Register from "./pages/Registerpage/Register";
import Start from "./pages/Startpage/Start";
import Share from "./pages/Sharepage/Share";
import Diarylist from "./pages/Diarylistpage/Diarylist";
import Diarywrite from "./pages/Diarywritepage/Diarywrite";
import Mypage from "./pages/Mypage/Mypage";
import Editpi from "./pages/Mypage/Editpi";
import Changepswd from "./pages/Mypage/Changepswd";
import Time from "./pages/Timepage/Time";
import Test from "./pages/Sharepage/Test";
import Total from "./pages/Calendarpage/Total";

const store = createStore(rootReducer, composeWithDevTools(applyMiddleware()));

function App() {
  return (
    <Router>
      <Provider store={store}> {/* Redux Provider */}
        <Routes>
          <Route path="/" element={<Start />} />
          <Route path="/start" element={<Start />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/share" element={<Share />} />
          <Route path="/diarylist" element={<Diarylist />} />
          <Route path="/diarywrite" element={<Diarywrite />} />
          <Route path="/calendar" element={<Total />} />
          <Route path="/mypage" element={<Mypage />} />
          <Route path="/time" element={<Time />} />
          <Route path="/editPI" element={<Editpi />} />
          <Route path="/changepswd" element={<Changepswd />} />
          <Route path="/test" element={<Test />} />
          <Route path="/@username">
            <Route index element={<Start />} />
          </Route>
        </Routes>
      </Provider>
    </Router>
  );
}

export default App;
